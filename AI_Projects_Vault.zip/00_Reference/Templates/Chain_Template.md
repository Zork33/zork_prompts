# 🔗 Prompt Chain: {{title}}

## Step 1 — Контекст
[[01_Context.md]]

## Step 2 — Промпт
[[02_Prompts/]]

## Step 3 — Результат
[[03_Results/]]

## Step 4 — Примечания
[[99_Notes.md]]
