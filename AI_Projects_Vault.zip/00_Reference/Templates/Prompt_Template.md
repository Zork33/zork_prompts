---
title: {{title}}
project:
tags: [prompt]
status: draft
date: <% tp.date.now("YYYY-MM-DD") %>
---

## 🎯 Цель

## 💬 Промпт
```
(вставь текст промпта)
```

## 🤖 Ответ ChatGPT


## 🧩 Примечания
