# 💰 Treasury Related Prompts

- Все запросы, относящиеся к управлению казначейством.
